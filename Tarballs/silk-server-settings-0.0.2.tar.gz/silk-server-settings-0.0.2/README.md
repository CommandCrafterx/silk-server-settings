# 🛡️ Silk Server Settings

**Silk Server Settings** is a simple and powerful system management and security tool for Silk Server.  
It provides a clean GTK 4 + LibAdwaita interface for handling core server controls.

# 📦 Dependencies
python3-psutil python3-gobject gtk4 libadwaita